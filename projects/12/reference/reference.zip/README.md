* 尽量用位掩码操作和加减法代替乘除法 
* 尽量少使用函数调用 开销太高

#### 内存管理
[内存管理算法](http://nand2tetris-questions-and-answers-forum.32033.n3.nabble.com/New-Heap-Management-algorithm-Coursera-version-td4032026.html)

#### 圆 直线
bresenham算法画圆
